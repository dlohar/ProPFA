/* run.config
   DONTRUN: linked with multiple_file_1.c which is the real test.
*/
/*@ requires y <= 0; */
int g(int y);
