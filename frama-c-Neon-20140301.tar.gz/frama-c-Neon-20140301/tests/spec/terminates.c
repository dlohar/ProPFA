/*@
terminates c>0;
assigns \nothing;
*/
void f (int c) { while(!c); return;}
