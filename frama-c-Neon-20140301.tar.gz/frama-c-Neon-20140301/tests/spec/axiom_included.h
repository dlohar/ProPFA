/*@ axiomatic foo { axiom foo: \true; } */
