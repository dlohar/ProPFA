void f() {
  //@ loop invariant i >= 0;
  for (int i = 0; i < 10; ++i) ;
}
