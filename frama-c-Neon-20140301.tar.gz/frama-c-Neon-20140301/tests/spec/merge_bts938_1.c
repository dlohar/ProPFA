/* run.config
   DONTRUN: main test is merge_bts938.c
*/

#include "tests/spec/merge_bts938.h"

//@ ensures test1: \true;
int main(void);
