

//@ lemma cos_pi: \cos(\pi) == -1.0;
