/* run.config
  OPT: -load-script tests/misc/bug_0209.ml
*/

// Everything is done by the script
