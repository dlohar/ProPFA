/* run.config
   DONTRUN: linked with abstract_struct_1.c
*/

struct abstracttype { int c1; int c2; };
