/* run.config
   DONTRUN: test for the gui only
*/

#include "inline.h"

int main () {
  int x = f(42);
  return 0;
}
