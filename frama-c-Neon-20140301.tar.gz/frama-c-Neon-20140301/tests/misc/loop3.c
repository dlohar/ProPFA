
int i,j,k;
#include "any_int.c"

void main(void)
{
  j = 0;
  int b = any_int ();

//  if (b<0) j=b;
  for (i=0;i<100;i++) {j = j+3; k = k + 8;};
}

