/* config.h.  Generated from config.h.in by configure.  */
/* #undef HAVE_WCHAR_T */

#define HAVE_STDLIB_H 1

#define HAVE_STRINGS_H 1

/* #undef HAVE_SYS_TIME_H */

#define HAVE_UNISTD_H 1

/* #undef HAVE_CONST */

/* #undef HAVE_INLINE */

/* #undef HAVE_TIME_H */

/* #undef HAVE_MEMCP */

/* #undef HAVE_MKDIR */

/* #undef HAVE_SELECT */

/* #undef HAVE_SOCKET */

#define TYPE_SIZE_T "unsigned long"

#define TYPE_WCHAR_T "int"
