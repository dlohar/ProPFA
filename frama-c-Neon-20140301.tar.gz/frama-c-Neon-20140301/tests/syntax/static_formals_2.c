/* run.config
DONTRUN: main test in static_formals_1.c
*/

#include "static_formals.h"

int h() { return f(6); }
