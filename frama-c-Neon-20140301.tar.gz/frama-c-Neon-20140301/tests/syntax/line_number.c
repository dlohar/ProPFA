//@ assert \result == 0;
extern int p(void void);
