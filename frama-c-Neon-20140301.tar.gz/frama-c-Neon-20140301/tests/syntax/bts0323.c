/* run.config
   STDOPT: +"tests/syntax/bts0323-2.c"
*/
#include "bts0323.h"
void f() { x = 0; }
